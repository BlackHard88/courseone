import Cocoa

var fibarray  = [Int]()
fibarray.append(0)
fibarray.append(1)
for i in 2...49{
    fibarray.append(fibarray[i-2]+fibarray[i-1])
}
print(fibarray)
